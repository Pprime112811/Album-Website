PRIME CREATOR FINAL BUILD
Upload all files to the root of the GitHub Pages repository.
The web app includes its PWA manifest, service worker, mobile layout,
dashboard, music, Team Prime, academy, creator tools, profile and local data.
HTTPS hosting is required for install/offline features. Turning this into a
store-distributed Android/iOS app is a later packaging/signing step.
